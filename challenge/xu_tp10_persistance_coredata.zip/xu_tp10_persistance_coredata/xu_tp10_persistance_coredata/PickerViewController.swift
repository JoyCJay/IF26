//
//  PickerViewController.swift
//  xu_tp10_persistance_coredata
//
//  Created by if26-grp1 on 06/12/2019.
//  Copyright © 2019 if26-grp1. All rights reserved.
//
import CoreData
import UIKit

class PickerViewController: UIViewController, UIPickerViewDataSource, UIPickerViewDelegate {
    
    @IBOutlet weak var picker: UIPickerView!
    @IBOutlet weak var selectBTN: UIButton!
    
    var result: [Any] = []
    let dataSource = ["CS","TM","stage","HT","EC"]
    var selectedCategorie = ""
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        // Do any additional setup after loading the view.
    }
    
    func numberOfComponents(in pickerView: UIPickerView) -> Int {
        return 1
    }
    
    func pickerView(_ pickerView: UIPickerView, titleForRow row: Int, forComponent component: Int) -> String? {
        return dataSource[row]
    }
    
    func pickerView(_ pickerView: UIPickerView, numberOfRowsInComponent component: Int) -> Int {
        return dataSource.count
    }
    
    func pickerView(_ pickerView: UIPickerView, didSelectRow row: Int, inComponent component: Int) {
        selectedCategorie = dataSource[row]
    }
    
    @IBAction func click(_ sender: Any) {
        let appDelegate = UIApplication.shared.delegate as! AppDelegate
        let context = appDelegate.persistentContainer.viewContext
        
        let request = NSFetchRequest<NSFetchRequestResult>(entityName: "Modules")
        
        
        request.returnsObjectsAsFaults = false
        
        do {
            result = try context.fetch(request)
            
             if result.count > 0 {
                for r in result as! [NSManagedObject] {
                    if let categorie = r.value(forKey: "categorie") as? String{
                        if selectedCategorie == categorie{
                            
                            let sigle = r.value(forKey: "sigle") as! String
                            let parcours = r.value(forKey: "parcours") as! String
                            let credit = r.value(forKey: "credit") as! String
                            print("\(sigle) - \(parcours) - \(credit)")
                        }
                    }
                }
             }
        } catch  {
            
        }
    }
    

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */

}
