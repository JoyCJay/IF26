//
//  ListeViewController.swift
//  xu_tp10_persistance_coredata
//
//  Created by if26-grp1 on 03/12/2019.
//  Copyright © 2019 if26-grp1. All rights reserved.
//

import UIKit
import CoreData

class ListeViewController: UIViewController {

    @IBOutlet weak var sigleLable: UILabel!
    @IBOutlet weak var categorieLable: UILabel!
    @IBOutlet weak var parcoursLable: UILabel!
    @IBOutlet weak var creditLable: UILabel!
    
    @IBOutlet weak var modulesLength: UILabel!
    override func viewDidLoad() {
        super.viewDidLoad()
        
        
        let appDelegate = UIApplication.shared.delegate as! AppDelegate
        let context = appDelegate.persistentContainer.viewContext
        
        let request = NSFetchRequest<NSFetchRequestResult>(entityName: "Modules")
        
        request.returnsObjectsAsFaults = false
        
        do {
            let result = try context.fetch(request)
            modulesLength.text = "Vous avez " + String(result.count) + " modules"
            if result.count > 0 {
                for r in result as! [NSManagedObject] {
                    if let sigle = r.value(forKey: "sigle") as? String {
                        sigleLable.text = sigle
                    }
                    if let categorie = r.value(forKey: "categorie") as? String {
                        categorieLable.text = categorie
                    }
                    if let parcours = r.value(forKey: "parcours") as? String {
                        parcoursLable.text = parcours
                    }
                    if let credit = r.value(forKey: "credit") as? String {
                        creditLable.text = credit
                    }
                    // Thread.sleep(forTimeInterval: 1)
                }
            }
        } catch  {
            
        }
        
        // sigleLable.text = "modified"
        // categorieLable.text = "modified"
        // parcoursLable.text = "modified"
        // creditLable.text = "modified"
        
        // Do any additional setup after loading the view.
    }
    

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */

}
