//
//  AjouteViewController.swift
//  xu_tp10_persistance_coredata
//
//  Created by if26-grp1 on 03/12/2019.
//  Copyright © 2019 if26-grp1. All rights reserved.
//

import UIKit
import CoreData

class AjouteViewController: UIViewController {

    @IBOutlet weak var sigleTV: UITextField!
    @IBOutlet weak var categorieTV: UITextField!
    @IBOutlet weak var parcoursTV: UITextField!
    @IBOutlet weak var creditTV: UITextField!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        //sigleTV.text = "ssigle"
        //categorieTV.text = "ccqte"
        //parcoursTV.text = "pparcour"
        //creditTV.text = "ccre"
        // Do any additional setup after loading the view.
    }
    
    @IBAction func ajoutBTN(_ sender: Any) {
        let appDelegate = UIApplication.shared.delegate as! AppDelegate
        let context = appDelegate.persistentContainer.viewContext
        
        let newModule = NSEntityDescription.insertNewObject(forEntityName: "Modules", into: context)
        
        newModule.setValue(sigleTV.text, forKey: "sigle")
        newModule.setValue(categorieTV.text, forKey: "categorie")
        newModule.setValue(parcoursTV.text, forKey: "parcours")
        newModule.setValue(creditTV.text, forKey: "credit")
        
        do {
            try context.save()
            print("context saved")
        } catch  {
            print("context save err")
        }
    }
    
    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */

}

